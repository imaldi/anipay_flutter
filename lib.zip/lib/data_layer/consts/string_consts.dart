// const BASE_URL = "http://188.166.251.24:17076";
const BASE_URL = "http://188.166.251.24:37076";
const EA_MOBILES = "/ea/mobiles";
const SECRET_KEY = "a8eeea6c3c839d8b96a8a1a43a13e5c3";
const ANIPAY_LOGIN = "1000";
